import projetjava.repositories.PatientRepository;
import projetjava.repositories.MedecinRepository;     // Import
import projetjava.repositories.RendezVousRepository;  // Import
import projetjava.service.MedicalService;
import projetjava.observer.NotificationManager;
import projetjava.observer.ConsoleLogger;
import projetjava.presentation.SimpleHttpServer;

import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        try {
            // 1. Initialiser tous les repositories
            PatientRepository patientRepo = new PatientRepository();
            MedecinRepository medecinRepo = new MedecinRepository();   // Ajout
            RendezVousRepository rdvRepo = new RendezVousRepository(); // Ajout

            NotificationManager notifManager = new NotificationManager();
            notifManager.subscribe(new ConsoleLogger());

            // 2. Initialiser le Service avec TOUS les repos
            MedicalService service = new MedicalService(
                    patientRepo,
                    medecinRepo,
                    rdvRepo,
                    notifManager
            );

            // 3. Lancer le serveur
            SimpleHttpServer server = new SimpleHttpServer(service);
            server.start();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}