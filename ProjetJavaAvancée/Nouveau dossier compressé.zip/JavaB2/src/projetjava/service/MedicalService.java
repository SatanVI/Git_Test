package projetjava.service;

// Assurez-vous que ces imports correspondent bien à vos dossiers
import projetjava.model.Patient;
import projetjava.model.Medecin;
import projetjava.model.RendezVous;
import projetjava.repositories.IRepository;
import projetjava.util.MedicalFactory;
import projetjava.observer.NotificationManager;

import java.util.List;

public class MedicalService {
    // Dépendances (Repositories + Notification)
    private IRepository<Patient> patientRepo;
    private IRepository<Medecin> medecinRepo;
    private IRepository<RendezVous> rdvRepo;
    private NotificationManager notificationManager;

    // Constructeur avec injection de toutes les dépendances
    public MedicalService(IRepository<Patient> patientRepo,
                          IRepository<Medecin> medecinRepo,
                          IRepository<RendezVous> rdvRepo,
                          NotificationManager notifManager) {
        this.patientRepo = patientRepo;
        this.medecinRepo = medecinRepo;
        this.rdvRepo = rdvRepo;
        this.notificationManager = notifManager;
    }

    // =================================================================
    // 1. GESTION DES PATIENTS
    // =================================================================

    public Patient registerPatient(String nom, String email) {
        // Pattern Factory : Création
        Patient p = MedicalFactory.createPatient(nom, email);

        // Pattern Repository : Sauvegarde
        patientRepo.save(p);

        // Pattern Observer : Notification
        notificationManager.notifyAll("Nouveau patient créé : " + nom);

        return p;
    }

    public List<Patient> getAllPatients() {
        return patientRepo.findAll();
    }

    public void deletePatient(Long id) {
        patientRepo.delete(id);
        notificationManager.notifyAll("Patient supprimé : ID " + id);
    }

    // =================================================================
    // 2. GESTION DES MÉDECINS
    // =================================================================

    public Medecin registerMedecin(String nom, String specialite) {
        Medecin m = MedicalFactory.createMedecin(nom, specialite);
        medecinRepo.save(m);
        // On peut notifier ou non, selon le besoin (ici silencieux)
        return m;
    }

    public List<Medecin> getAllMedecins() {
        return medecinRepo.findAll();
    }

    // =================================================================
    // 3. GESTION DES RENDEZ-VOUS (Cycle de vie complet)
    // =================================================================

    // Étape A : Créer (Planifier)
    public RendezVous createRendezVous(Long patientId, Long medecinId, String date) {
        RendezVous rdv = MedicalFactory.createRendezVous(patientId, medecinId, date);
        rdvRepo.save(rdv);
        notificationManager.notifyAll("Nouveau RDV planifié le " + date);
        return rdv;
    }

    // Étape B : Démarrer le RDV
    public boolean startRendezVous(Long id) {
        RendezVous rdv = rdvRepo.findById(id);

        // On ne démarre que si le RDV existe et qu'il est "PLANIFIE"
        if (rdv != null && "PLANIFIE".equals(rdv.getStatut())) {
            rdv.setStatut("EN_COURS");
            // Pas besoin de refaire save() car l'objet est modifié en mémoire (référence)
            notificationManager.notifyAll("Rendez-vous n°" + id + " a démarré.");
            return true;
        }
        return false; // Échec (RDV introuvable ou déjà démarré/fini)
    }

    // Étape C : Terminer le RDV
    public boolean finishRendezVous(Long id) {
        RendezVous rdv = rdvRepo.findById(id);

        // On ne termine que si le RDV est "EN_COURS"
        if (rdv != null && "EN_COURS".equals(rdv.getStatut())) {
            rdv.setStatut("TERMINE");
            notificationManager.notifyAll("Rendez-vous n°" + id + " est terminé.");
            return true;
        }
        return false; // Échec
    }

    public List<RendezVous> getAllRendezVous() {
        return rdvRepo.findAll();
    }
}