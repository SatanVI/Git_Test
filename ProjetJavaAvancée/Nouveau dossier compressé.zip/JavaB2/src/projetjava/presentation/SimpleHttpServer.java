package projetjava.presentation;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;

// Assurez-vous que ces imports correspondent à vos dossiers
import projetjava.service.MedicalService;
import projetjava.model.Medecin;
import projetjava.model.RendezVous;
import projetjava.model.Patient;

import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class SimpleHttpServer {
    private MedicalService medicalService;

    public SimpleHttpServer(MedicalService service) {
        this.medicalService = service;
    }

    public void start() throws IOException {
        // Création du serveur sur le port 8000
        HttpServer server = HttpServer.create(new InetSocketAddress(8000), 0);

        // 1. Endpoint Santé (Health Check)
        server.createContext("/health", exchange -> sendResponse(exchange, 200, "{\"status\":\"OK\"}"));

        // 2. Gestion des Patients
        server.createContext("/patients", new PatientHandler());

        // 3. Gestion des Médecins
        server.createContext("/medecins", new MedecinHandler());

        // 4. Création des Rendez-vous
        server.createContext("/appointments", new RendezVousHandler());

        // 5. Gestion du cycle de vie des Rendez-vous (Démarrer / Terminer)
        server.createContext("/appointments/start", new RendezVousActionHandler("START"));
        server.createContext("/appointments/finish", new RendezVousActionHandler("FINISH"));

        server.setExecutor(null); // Default executor
        server.start();
        System.out.println("✅ Serveur démarré sur http://localhost:8000");
    }

    // =========================================================
    // HANDLER PATIENTS (GET, POST, DELETE)
    // =========================================================
    class PatientHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String method = exchange.getRequestMethod();

            if ("GET".equals(method)) {
                // Lister les patients
                List<Patient> patients = medicalService.getAllPatients();
                StringBuilder json = new StringBuilder("[");
                for (Patient p : patients) {
                    json.append(p.toJson()).append(",");
                }
                if (patients.size() > 0) json.deleteCharAt(json.length() - 1);
                json.append("]");
                sendResponse(exchange, 200, json.toString());

            } else if ("POST".equals(method)) {
                // Créer un patient
                String body = getBody(exchange);
                String nom = extractJsonValue(body, "nom");
                String email = extractJsonValue(body, "email");

                if (nom != null && !nom.isEmpty()) {
                    Patient created = medicalService.registerPatient(nom, email);
                    sendResponse(exchange, 201, created.toJson());
                } else {
                    sendResponse(exchange, 400, "{\"error\":\"Nom manquant\"}");
                }

            } else if ("DELETE".equals(method)) {
                // Supprimer un patient (via URL ?id=X)
                String query = exchange.getRequestURI().getQuery();
                if (query != null && query.contains("id=")) {
                    try {
                        String idStr = query.split("=")[1];
                        Long id = Long.parseLong(idStr);
                        medicalService.deletePatient(id);
                        sendResponse(exchange, 204, "");
                    } catch (Exception e) {
                        sendResponse(exchange, 400, "{\"error\":\"ID invalide\"}");
                    }
                } else {
                    sendResponse(exchange, 400, "{\"error\":\"ID manquant\"}");
                }

            } else {
                sendResponse(exchange, 405, "Method Not Allowed");
            }
        }
    }

    // =========================================================
    // HANDLER MEDECINS (GET, POST)
    // =========================================================
    class MedecinHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String method = exchange.getRequestMethod();

            if ("GET".equals(method)) {
                List<Medecin> list = medicalService.getAllMedecins();
                StringBuilder json = new StringBuilder("[");
                for (Medecin m : list) json.append(m.toJson()).append(",");
                if (list.size() > 0) json.deleteCharAt(json.length() - 1);
                json.append("]");
                sendResponse(exchange, 200, json.toString());

            } else if ("POST".equals(method)) {
                String body = getBody(exchange);
                String nom = extractJsonValue(body, "nom");
                String spec = extractJsonValue(body, "specialite");
                Medecin created = medicalService.registerMedecin(nom, spec);
                sendResponse(exchange, 201, created.toJson());
            } else {
                sendResponse(exchange, 405, "Method Not Allowed");
            }
        }
    }

    // =========================================================
    // HANDLER RENDEZ-VOUS - CRÉATION (POST)
    // =========================================================
    class RendezVousHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("POST".equals(exchange.getRequestMethod())) {
                String body = getBody(exchange);
                try {
                    Long pId = Long.parseLong(extractJsonValue(body, "patientId"));
                    Long mId = Long.parseLong(extractJsonValue(body, "medecinId"));
                    String date = extractJsonValue(body, "date");

                    RendezVous rdv = medicalService.createRendezVous(pId, mId, date);
                    sendResponse(exchange, 201, rdv.toJson());
                } catch (Exception e) {
                    sendResponse(exchange, 400, "{\"error\":\"Donnees invalides (IDs ou Date)\"}");
                }
            } else {
                sendResponse(exchange, 404, "Only POST allowed");
            }
        }
    }

    // =========================================================
    // HANDLER RENDEZ-VOUS - ACTIONS (START / FINISH)
    // =========================================================
    class RendezVousActionHandler implements HttpHandler {
        private String actionType; // "START" ou "FINISH"

        public RendezVousActionHandler(String actionType) {
            this.actionType = actionType;
        }

        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("POST".equals(exchange.getRequestMethod())) {
                String query = exchange.getRequestURI().getQuery();

                if (query != null && query.contains("id=")) {
                    try {
                        String idStr = query.split("=")[1];
                        Long id = Long.parseLong(idStr);
                        boolean success = false;

                        if ("START".equals(actionType)) {
                            success = medicalService.startRendezVous(id);
                        } else if ("FINISH".equals(actionType)) {
                            success = medicalService.finishRendezVous(id);
                        }

                        if (success) {
                            sendResponse(exchange, 200, "{\"status\":\"Succes\", \"action\":\"" + actionType + "\"}");
                        } else {
                            sendResponse(exchange, 400, "{\"error\":\"Impossible de changer le statut (RDV introuvable ou etat incorrect)\"}");
                        }
                    } catch (Exception e) {
                        sendResponse(exchange, 400, "{\"error\":\"ID invalide\"}");
                    }
                } else {
                    sendResponse(exchange, 400, "{\"error\":\"ID manquant dans l'URL (ex: ?id=1)\"}");
                }
            } else {
                sendResponse(exchange, 405, "Method Not Allowed (Use POST)");
            }
        }
    }

    // =========================================================
    // MÉTHODES UTILITAIRES (HELPERS)
    // =========================================================

    // 1. Lire le corps de la requête
    private String getBody(HttpExchange exchange) throws IOException {
        InputStream is = exchange.getRequestBody();
        return new String(is.readAllBytes(), StandardCharsets.UTF_8);
    }

    // 2. Envoyer la réponse HTTP
    private void sendResponse(HttpExchange exchange, int statusCode, String response) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.sendResponseHeaders(statusCode, response.length());
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }

    // 3. Parser JSON manuel simple
    private String extractJsonValue(String json, String key) {
        try {
            String searchKey = "\"" + key + "\":";
            int startIndex = json.indexOf(searchKey);
            if (startIndex == -1) return null;

            startIndex += searchKey.length();

            while (startIndex < json.length() && json.charAt(startIndex) == ' ') {
                startIndex++;
            }

            if (json.charAt(startIndex) == '"') {
                startIndex++;
                int endIndex = json.indexOf("\"", startIndex);
                return json.substring(startIndex, endIndex);
            } else {
                int endIndex = json.indexOf(",", startIndex);
                if (endIndex == -1) endIndex = json.indexOf("}", startIndex);
                return json.substring(startIndex, endIndex).trim();
            }
        } catch (Exception e) {
            return null;
        }
    }
}