package projetjava.util;
import projetjava.model.Medecin;
import projetjava.model.Patient;
import projetjava.model.RendezVous;
import java.util.concurrent.atomic.AtomicLong;

public class MedicalFactory {
    private static final AtomicLong patientIdGenerator = new AtomicLong(1);

    public static Patient createPatient(String nom, String email) {
        return new Patient(patientIdGenerator.getAndIncrement(), nom, email);
    }

    public static Medecin createMedecin(String nom, String specialite) {
                    return null;
    }

    public static RendezVous createRendezVous(Long patientId, Long medecinId, String date) {
            return null;
    }


    // Ajoutez ici createMedecin, createRendezVous...
}