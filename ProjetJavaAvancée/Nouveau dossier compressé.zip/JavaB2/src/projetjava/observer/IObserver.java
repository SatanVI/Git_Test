package projetjava.observer;

public interface IObserver {
    void update(String message);
}