package projetjava.repositories;
import projetjava.model.Patient;
import java.util.*;

public class PatientRepository implements IRepository<Patient> {
    private Map<Long, Patient> database = new HashMap<>();

    @Override
    public void save(Patient patient) {
        database.put(patient.getId(), patient);
    }

    @Override
    public Patient findById(Long id) {
        return database.get(id);
    }

    @Override
    public List<Patient> findAll() {
        return new ArrayList<>(database.values());
    }

    @Override
    public void delete(Long id) {
        database.remove(id);
    }
}