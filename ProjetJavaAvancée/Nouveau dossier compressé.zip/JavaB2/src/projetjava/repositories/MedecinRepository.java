package projetjava.repositories;

import projetjava.model.Medecin; // Vérifiez que le chemin vers 'model' est bon (ex: projetjava.model.Medecin)
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MedecinRepository implements IRepository<Medecin> {
    // Simule une base de données en mémoire
    private Map<Long, Medecin> database = new HashMap<>();

    @Override
    public void save(Medecin medecin) {
        database.put(medecin.getId(), medecin);
    }

    @Override
    public Medecin findById(Long id) {
        return database.get(id);
    }

    @Override
    public List<Medecin> findAll() {
        return new ArrayList<>(database.values());
    }

    @Override
    public void delete(Long id) {
        database.remove(id);
    }
}