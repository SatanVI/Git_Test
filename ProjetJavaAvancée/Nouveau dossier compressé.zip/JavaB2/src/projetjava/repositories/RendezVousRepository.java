package projetjava.repositories;

import projetjava.model.RendezVous; // Vérifiez l'import
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RendezVousRepository implements IRepository<RendezVous> {
    private Map<Long, RendezVous> database = new HashMap<>();

    @Override
    public void save(RendezVous rdv) {
        database.put(rdv.getId(), rdv);
    }

    @Override
    public RendezVous findById(Long id) {
        return database.get(id);
    }

    @Override
    public List<RendezVous> findAll() {
        return new ArrayList<>(database.values());
    }

    @Override
    public void delete(Long id) {
        database.remove(id);
    }
}